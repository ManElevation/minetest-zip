Minetest Game mod: xpanes
=========================
See license.txt for license information.

Authors of source code
----------------------
Originally by xyz (MIT)
BlockMen (MIT)
sofar (MIT)
Various Minetest developers and contributors (MIT)

Authors of media (textures)
---------------------------
xyz (CC BY-SA 3.0):
  All textures not mentioned below.

Gambit (CC BY-SA 3.0):
  xpanes_bar.png

paramat (CC BY-SA 3.0):
  xpanes_bar_top.png
